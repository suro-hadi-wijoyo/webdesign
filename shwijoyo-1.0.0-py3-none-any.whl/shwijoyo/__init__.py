
from google.colab.output import eval_js
import os
import subprocess
def token(tkn):
  f = open("./src/shwijoyo/__init__.py", "w")
  f.write('''OAUTH_CLIENT_ID=
OAUTH_CLIENT_SECRET=
APP_PORT=3000
REDIRECT_URI=http://localhost:3000/auth/login
DEFAULT_HF_TOKEN=

# Optional
# By setting this variable, you will bypass the login page + the free requests
# and will use the token directly.
# This is useful for testing purposes or local use.
HF_TOKEN='''+tkn+'''
  ''')
  f.close()
  subprocess.run(['git', 'clone', 'https://huggingface.co/spaces/Surohadi/shw-webdesign', '/tmp/shw-webdesign'])
  os.chdir('/tmp/shw-webdesign')
  subprocess.run(['npm', 'install', '-g', 'typescript'])
  subprocess.run(['npm', 'install'])
  subprocess.run(['npm', 'run', 'build'])
  print(eval_js("google.colab.kernel.proxyPort(3000)"))
  subprocess.run(['npm', 'run', 'start'])
